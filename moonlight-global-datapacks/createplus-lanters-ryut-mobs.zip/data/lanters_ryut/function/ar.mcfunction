# Ryut nao tem ar (Cosmonautics): mortos-vivos nao respiram, entao o folego deles fica sempre cheio
execute in createlanterns:ryut positioned 0 0 0 as @e[type=#minecraft:undead,distance=0..] run data modify entity @s Air set value 300s
schedule function lanters_ryut:ar 1s replace
