# Liga o ciclo que mantem o ar dos mortos-vivos de Ryut
schedule function lanters_ryut:ar 1s replace
