Read Me!

If you are also using 'Combee MC Remodel', copy all folders inside this directory into 'Combee MC Remodel v2/assets/xaerominimap/entity/icon/sprite' to replace the original Combee icons. 

Also, don't forget to place 'Combee MC Remodel v2' above 'E19 Cobblemon Minimap Icons' in the resource pack list.

Combee MC Remodel: https://modrinth.com/resourcepack/combee-mc-remodel