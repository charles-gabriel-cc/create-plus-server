Read Me!

If you are also using 'Gholdengo Shiny Fix', copy all folders inside this directory into 'Shiny Gholdengo Fix/assets/xaerominimap/entity/icon/sprite' to replace the original shiny Gholdengo icons. 

Also, don't forget to place 'Gholdengo Shiny Fix' above 'E19 Cobblemon Minimap Icons' in the resource pack list.

Gholdengo Shiny Fix: https://modrinth.com/resourcepack/gholdengo-shiny-fix